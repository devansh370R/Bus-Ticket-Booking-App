import 'dart:ui';

class Data_Variable {
  static String userEmailId = "";
  static String useruid="";
  static DateTime selectedDate = DateTime.now();
  static Color buttoncolor=Color.fromARGB(255, 232, 116, 116);
  static Color backgroundColor= Color.fromARGB(255, 244, 244, 244);
  static Color temlatecolor=Color.fromARGB(255, 161, 221, 229);
}