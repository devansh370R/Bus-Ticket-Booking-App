class MyRoutes{
  static String loginpage="/loginpage";
  static String homepage="/homepage";
  static String registrationpage="/registration";
}