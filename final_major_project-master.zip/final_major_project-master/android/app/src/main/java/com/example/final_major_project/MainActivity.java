package com.example.final_major_project;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
